cd ./outputs || exit
time /home/$USER/Cosmica-dev/Cosmica_V9-speedtest/exefiles/Cosmica -vvv -i /home/$USER/Cosmica-dev/Cosmica_V9-speedtest/runned_tests/AMS-02_PRL2015/Input_Proton_TKO_20110509_20131121_r00100_lat00000.txt
cd ..