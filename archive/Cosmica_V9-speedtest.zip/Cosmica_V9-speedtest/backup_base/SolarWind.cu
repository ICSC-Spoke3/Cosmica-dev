#include "GenComputation.cuh"
#include "HelModVariableStructure.cuh"
#include "VariableStructure.cuh"

#include "HeliosphereModel.cuh"
#include "SolarWind.cuh"

  ////////////////////////////////////////////////////////////////
  //..... Solar Wind Speed   .....................................
  ////////////////////////////////////////////////////////////////
__device__ float SolarWindSpeed(unsigned char InitZone,signed char HZone, float r, float th, float phi){
   /* Author: SDT - adapted for CUDA in Feb 2022
   * description: return the solar wind speed
   *
   * \param HZone Index of Heliosphere region
   * \param part  Pseudoparticle position
   */
   float V0=(HZone<Heliosphere.Nregions)?LIM[HZone+InitZone].V0:HS[InitZone].V0;
   // heliosheat (or near to)...............................
   if (HZone>=Heliosphere.Nregions-1){
      float RtsDirection  = Boundary(th,phi,Heliosphere.RadBoundary_effe[InitZone].Rts_nose, Heliosphere.RadBoundary_effe[InitZone].Rts_tail);
      if (r>RtsDirection-L_tl){
         float RtsRWDirection= Boundary(th,phi,Heliosphere.RadBoundary_real[InitZone].Rts_nose, Heliosphere.RadBoundary_real[InitZone].Rts_tail);
         float DecreasFactor = SmoothTransition(1.f, 1.f/s_tl, RtsDirection, L_tl, r);
         if (r>RtsDirection){
            DecreasFactor*=(RtsRWDirection/(RtsRWDirection -RtsDirection + r))*(RtsRWDirection/(RtsRWDirection -RtsDirection + r));
         }
         return V0*DecreasFactor;
      }
   }
   // inner Heliosphere .........................
   if (Heliosphere.IsHighActivityPeriod[InitZone]){
      // high solar activity
      return V0;
   }else{
      // low solar activity
      float VswAngl=1;
      if (Vhigh/V0<=2.f){VswAngl=Vhigh/V0-1.f;}
      if (fabsf(cosf(th))>VswAngl){
         return Vhigh ;
      }else{
         return (V0*(1+fabsf(cosf(th))));
      }
   }
   return V0;
}
__device__ float DerivativeOfSolarWindSpeed_dtheta(unsigned char InitZone,signed char HZone, float r, float th, float phi){
   /* Author: SDT - adapted for CUDA in Feb 2022
   * description: return the derivative of solar wind speed in d theta
   *
   * \param HZone Index of Heliosphere region
   * \param part  Pseudoparticle position
   */
   float V0= (HZone<Heliosphere.Nregions)?LIM[HZone+InitZone].V0:HS[InitZone].V0;
   // inner Heliosphere .........................
   if (Heliosphere.IsHighActivityPeriod[InitZone]){
      // high solar activity
      return 0;
   }else{
      // low solar activity
      float VswAngl=1;
      if (Vhigh/V0<=2.f){VswAngl=Vhigh/V0-1.f;}
      if (fabsf(cosf(th))>VswAngl){
         return 0 ;
      }else{
         if (cosf(th)<0)  return V0*sinf(th);
         if (cosf(th)==0) return 0.f;
         if (cosf(th)>0)  return -V0*sinf(th);
      }
   }
   // heliosheat ...............................
   if (HZone>=Heliosphere.Nregions-1){
      float RtsDirection  = Boundary(th,phi,Heliosphere.RadBoundary_effe[InitZone].Rts_nose, Heliosphere.RadBoundary_effe[InitZone].Rts_tail);
      if (r>RtsDirection-L_tl){
         return 0;
      }
   }
   return 0;
}