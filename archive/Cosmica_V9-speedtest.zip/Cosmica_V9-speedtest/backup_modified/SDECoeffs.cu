#include <math.h>
#include "VariableStructure.cuh"
#include "HelModVariableStructure.cuh"
#include "GenComputation.cuh"
#include "SolarWind.cuh"
#include "MagneticDrift.cuh"
#include "DiffusionModel.cuh"
#include "SDECoeffs.cuh"

__device__ struct DiffusionTensor_t trivial_DiffusionTensor_symmetric(int ZoneNum){
    struct DiffusionTensor_t KSym;

    return KSym;
}

__device__ struct Tensor3D_t trivial_SquareRoot_DiffusionTensor(struct DiffusionTensor_t KSym){
    struct Tensor3D_t Ddif;
    Ddif.rr = 1;

    return Ddif;
}

__device__ struct vect3D_t trivial_AdvectiveTerm(struct DiffusionTensor_t KSym){
    struct vect3D_t AdvTerm;

    return AdvTerm;
}

__device__ float trivial_EnergyLoss(){
    float R_loss = 0.1f;
    // float R_loss = 0;

    return R_loss;
}


////////////////////////////////////////////////////////////////
//.....  Diffusion Term  .....................................
////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////
//..... Simmetric component and derivative  ....................
////////////////////////////////////////////////////////////////

__device__ struct DiffusionTensor_t DiffusionTensor_symmetric(unsigned char InitZone, signed char HZone, float r, float th, float phi, float R, struct PartDescription_t pt, float GaussRndNumber){
  /*Authors: 2022 Stefano */
  /* * description: Evaluate the symmetric component (and derivative) of diffusion tensor in heliocentric coordinates
      \param InitZone initial Zone in the heliosphere (in the list of parameters)
      \param HZone   Zone in the Heliosphere
      \param part    particle position and energy
      \return  the symmetric component (and derivative) of diffusion tensor
   */
#define sq(x) ((x)*(x))
      DiffusionTensor_t KK;
    if (HZone < Heliosphere.Nregions) {
        const bool IsPolarRegion = fabsf(cosf(th)) > CosPolarZone;
        const float SignAsun = LIM[InitZone + HZone].Asun > 0 ? +1.f : -1.f;

        // @formatter:off
        float3 dK_dr;
        const auto [Kpar, Kperp1, Kperp2] =
                Diffusion_Tensor_In_HMF_Frame(InitZone, HZone, r, th, beta_R(R, pt), R, GaussRndNumber, dK_dr);

        const float PolSign = th - Pi / 2.f > 0 ? -1.f : +1.f;
        const float DelDirac = th == Pi / 2.f ? 1.f : 0.f;
        const float V_SW = SolarWindSpeed(InitZone, HZone, r, th, phi);

        const float Br = PolSign;
        const float Bth = IsPolarRegion ? r * delta_m / (rhelio * sinf(th)) : 0.f;
        const float Bph = -PolSign * (Omega * (r - rhelio) * sinf(th) / V_SW);

        const float dBr_dr = -2.f * PolSign / r;
        const float dBr_dth = -2.f * DelDirac;

        const float dBth_dr = IsPolarRegion ? -delta_m / (rhelio * sinf(th)) : 0.f;
        const float dBth_dth = IsPolarRegion ? r * delta_m / (rhelio * sinf(th) * sinf(th)) * -cosf(th) : 0.f;

        const float dBph_dr = PolSign * (r - 2.f * rhelio) * (Omega * sinf(th)) / (r * V_SW);
        const float dBph_dth = -(r - rhelio) * Omega * (-PolSign * (cosf(th) * V_SW - sinf(th) * DerivativeOfSolarWindSpeed_dtheta(InitZone,HZone, r, th, phi)) + 2.f * sinf(th) * V_SW * DelDirac) / (V_SW * V_SW);

        const float HMF_Mag2 = 1 + Bth * Bth + Bph * Bph;
        const float HMF_Mag = sqrtf(HMF_Mag2);
        const float dBMag_dr = (Br * dBr_dr + Bth * dBth_dr + Bph * dBph_dr) / HMF_Mag;
        const float dBMag_dth = (Br * dBr_dth + Bth * dBth_dth + Bph * dBph_dth) / HMF_Mag;

        const float sqrtBR2BT2 = sqrtf(sq(Br) + sq(Bth));
        const float dsqrtBR2BT2_dr = (Br * dBr_dr + Bth * dBth_dr) / sqrtBR2BT2;
        const float dsqrtBR2BT2_dth = (Br * dBr_dth + Bth * dBth_dth) / sqrtBR2BT2;


        const float sinPsi = SignAsun * (-Bph / HMF_Mag);
        const float cosPsi = sqrtBR2BT2 / HMF_Mag;
        const float sinZeta = SignAsun * (Bth / sqrtBR2BT2);
        const float cosZeta = SignAsun * (Br / sqrtBR2BT2);

        const float DsinPsi_dr = -SignAsun * (dBph_dr * HMF_Mag - Bph * dBMag_dr) / HMF_Mag2;
        const float DsinPsi_dtheta = -SignAsun * (dBph_dth * HMF_Mag - Bph * dBMag_dth) / HMF_Mag2;


        const float DcosPsi_dr = Bph * (-Br * Br * dBph_dr + Bph * Br * dBr_dr + Bth * (-Bth * dBph_dr + Bph * dBth_dr)) / (sqrtBR2BT2 * HMF_Mag2 * HMF_Mag);
        const float DcosPsi_dtheta = Bph * (-Br * Br * dBph_dth + Bph * Br * dBr_dth + Bth * (-Bth * dBph_dth + Bph * dBth_dth)) / (sqrtBR2BT2 * HMF_Mag2 * HMF_Mag);

        const float DsinZeta_dr = SignAsun * (dBth_dr * sqrtBR2BT2 - Bth * dsqrtBR2BT2_dr) / (sqrtBR2BT2 * sqrtBR2BT2);
        const float DsinZeta_dtheta = SignAsun * (dBth_dth * sqrtBR2BT2 - Bth * dsqrtBR2BT2_dth) / (sqrtBR2BT2 * sqrtBR2BT2);
        const float DcosZeta_dr = SignAsun * (dBr_dr * sqrtBR2BT2 - Br * dsqrtBR2BT2_dr) / (sqrtBR2BT2 * sqrtBR2BT2);
        const float DcosZeta_dtheta = SignAsun * (dBr_dth * sqrtBR2BT2 - Br * dsqrtBR2BT2_dth) / (sqrtBR2BT2 * sqrtBR2BT2);

        KK.rr = Kperp1 * sq(sinZeta) + sq(cosZeta) * (Kpar * sq(cosPsi) + Kperp2 * sq(sinPsi));
        KK.tt = Kperp1 * sq(cosZeta) + sq(sinZeta) * (Kpar * sq(cosPsi) + Kperp2 * sq(sinPsi));
        KK.pp = Kpar * sq(sinPsi) + Kperp2 * sq(cosPsi);
        KK.tr = sinZeta * cosZeta * (Kpar * sq(cosPsi) + Kperp2 * sq(sinPsi) - Kperp1);
        KK.pr = -(Kpar - Kperp2) * sinPsi * cosPsi * cosZeta;
        KK.pt = -(Kpar - Kperp2) * sinPsi * cosPsi * sinZeta;

        KK.DKrr_dr = 2.f * cosZeta * (sq(cosPsi) * Kpar + Kperp2 * sq(sinPsi)) * DcosZeta_dr + sinZeta * sinZeta * dK_dr.y + sq(cosZeta) * (2.f * cosPsi * Kpar * DcosPsi_dr + sq(cosPsi) * dK_dr.x + sinPsi * (sinPsi * dK_dr.z + 2.f * Kperp2 * DsinPsi_dr)) + 2.f * Kperp1 * sinZeta * DsinZeta_dr;
        KK.DKtt_dt = 2.f * cosZeta * Kperp1 * DcosZeta_dtheta + sq(sinZeta) * (2.f * cosPsi * Kpar * DcosPsi_dtheta + 2.f * sinPsi * Kperp2 * DsinPsi_dtheta) + 2.f * (sq(cosPsi) * Kpar + Kperp2 * sq(sinPsi)) * sinZeta * DsinZeta_dtheta;

        KK.DKrt_dr = (-Kperp1 + sq(cosPsi) * Kpar + Kperp2 * sq(sinPsi)) * (sinZeta * DcosZeta_dr + cosZeta * DsinZeta_dr) + cosZeta * sinZeta * (2.f * cosPsi * Kpar * DcosPsi_dr + sq(cosPsi) * dK_dr.x - dK_dr.y + sinPsi * (sinPsi * dK_dr.z + 2.f * Kperp2 * DsinPsi_dr));
        KK.DKtr_dt = (-Kperp1 + sq(cosPsi) * Kpar + Kperp2 * sq(sinPsi)) * (sinZeta * DcosZeta_dtheta + cosZeta * DsinZeta_dtheta) + cosZeta * sinZeta * (2.f * cosPsi * Kpar * DcosPsi_dtheta + 2.f * sinPsi * Kperp2 * DsinPsi_dtheta);
        KK.DKrp_dr = cosZeta * (Kperp2 - Kpar) * sinPsi * DcosPsi_dr + cosPsi * (Kperp2 - Kpar) * sinPsi * DcosZeta_dr + cosPsi * cosZeta * sinPsi * (dK_dr.z - dK_dr.x) + cosPsi * cosZeta * (Kperp2 - Kpar) * DsinPsi_dr;

        KK.DKtp_dt = (Kperp2 - Kpar) * (sinPsi * sinZeta * DcosPsi_dtheta + cosPsi * (sinZeta * DsinPsi_dtheta + sinPsi * DsinZeta_dtheta));
    } else {
        KK.rr = Diffusion_Coeff_heliosheat(InitZone, r, th, phi, beta_R(R, pt), R, KK.DKrr_dr);
    }
    // @formatter:on
#undef sq
    return KK;
}

///////////////////////////////////////////////////////
// ========== Decomposition of Diffution Tensor ======
// solve the equation (square root of diffusion tensor)
//  | a b c |   | g h i | | g l o |
//  | b d e | = | l m n | | h m p |
//  | c e f |   | o p q | | i n q |
//
// the diffusion tensor is written in the form that arise from SDE calculation
///////////////////////////////////////////////////////
__device__ struct Tensor3D_t SquareRoot_DiffusionTerm(signed char HZone, struct DiffusionTensor_t K, float r, float th, int* res){
/* * description:  ========== Decomposition of Diffusion Tensor ======
                  solve square root of diffusion tensor in heliocentric spherical coordinates
    \par Tensor3D K     input tensor
    \par qvect_t  part  particle Position
    \par int      &res  0 if ok; 1 if error
   */
    Tensor3D_t D;

    K.rr = 2.f * K.rr;
    D.rr = sqrtf(K.rr); // g = sqrt(a)
    if (HZone < Heliosphere.Nregions) {
        K.tr = 2.f * K.tr / r;
        K.tt = 2.f * K.tt / (r * r);
        K.pr = 2.f * K.pr / (r * sinf(th));
        K.pt = 2.f * K.pt / (r * r * sinf(th));
        K.pp = 2.f * K.pp / (r * r * sinf(th) * sinf(th));

        D.tr = K.tr / D.rr;
        D.pr = K.pr / D.rr;
        D.tt = sqrtf(K.tt - D.tr * D.tr);
        D.pt = 1.f / D.tt * (K.pt - D.tr * D.pr);
        D.pp = sqrtf(K.pp - D.pr * D.pr - D.pt * D.pt);
    }

    if (const float sum = D.rr + D.tr + D.pr + D.tt + D.pt + D.pp; isnan(sum) || isinf(sum)) {
        // TODO -- check an other solution... see Pei et al 2010 or Kopp et al 2012
        // not implemented since such cases are rare
        *res = 1;
    } else {
        *res = 0;
    }

    return D;
}

   ////////////////////////////////////////////////////////////////
   //.....  Advective term of SDE  ................................
   ////////////////////////////////////////////////////////////////

   // -- Radial --------------------------------------------------
   // dr_Adv = 2.f* K.rr/r + K.DKrr_dr + K.tr/(r*tantheta) + K.DKtr_dt/r + K.DKpr_dp/(r*sintheta) ;
   // dr_Adv+= - Vsw - vdr - vdns  ;
   // -- latitudinal ----------------------------------------------
   // dtheta_Adv = K.rt/(r2) + K.tt/(tantheta*r2 ) + K.DKrt_dr/r + K.DKtt_dt/r2 + K.DKpt_dp / (sintheta*r2);
   //_Adv+= - vdth/r;
   // -- Azimutal -------------------------------------------------
   // dphi_Adv = K.rp/(r2*sinf(theta))+ K.DKrp_dr/(r*sintheta) + K.DKtp_dt/( r2*sintheta) + K.DKpp_dp/( r2*sintheta*sintheta) ;
   // dphi_Adv+= - (vdph+vdns_p)/(r*sintheta);
   ///////////////////////////
__device__ struct vect3D_t AdvectiveTerm(unsigned char InitZone,signed char HZone, struct DiffusionTensor_t K, float r, float th, float phi, float R, struct PartDescription_t pt){
    vect3D_t AdvTerm = {2.f * K.rr / r + K.DKrr_dr, 0, 0};

    if (HZone < Heliosphere.Nregions) {
        AdvTerm.r += K.tr / (r * tanf(th)) + K.DKtr_dt / r;
        AdvTerm.th += K.tr / (r*r) + K.tt / (tanf(th) * (r*r)) + K.DKrt_dr / r + K.DKtt_dt / (r*r);

        AdvTerm.phi += K.pr / ((r*r) * sinf(th)) + K.DKrp_dr / (r * sinf(th)) + K.DKtp_dt / (
            (r*r) * sinf(th));
        struct vect3D_t v_drift = Drift_PM89(InitZone, HZone, r, th, phi, R, pt);
        AdvTerm.r -= v_drift.r;
        AdvTerm.th -= v_drift.th / r;
        AdvTerm.phi -= v_drift.phi / (r * sinf(th));
    }

    AdvTerm.r -= SolarWindSpeed(InitZone, HZone, r, th, phi);
    return AdvTerm;
}

  ////////////////////////////////////////////////////////////////
  //..... Energy loss term   .....................................
  ////////////////////////////////////////////////////////////////
__device__ float EnergyLoss(unsigned char InitZone, signed char HZone, float r, float th, float phi, float R) {
    if (HZone < Heliosphere.Nregions) {
        return 2.f / 3.f * SolarWindSpeed(InitZone, HZone, r, th, phi) / r * R;
    }
    return 0;
}


  ////////////////////////////////////////////////////////////////
  //..... Loss term  .............................................
  ////////////////////////////////////////////////////////////////
/* __device__ float LossTerm(unsigned char InitZone,signed char HZone, float r, float th, float phi, float Ek, float T0) {
   // xxx da completare
    if (HZone<Heliosphere.Nregions) {
        // inner Heliosphere .........................
        return 2.f*SolarWindSpeed(InitZone,HZone, r, th, phi)/r *( 1.f/3.f*( Ek*Ek+2*Ek*T0+ 2*T0*T0 )/( (Ek+T0)*(Ek+T0) ) -1 );
                                                                      // ( Ek*Ek+2*Ek*T0+ 2*T0*T0 )/( (Ek+T0)*(Ek+T0) ) -1 ) = -T*T0/((T+T0)*(T+T0))
    }

    else {
        // heliosheat ...............................
        // solar wind divergence is zero
        return 0;
    }

    return 1;
} */