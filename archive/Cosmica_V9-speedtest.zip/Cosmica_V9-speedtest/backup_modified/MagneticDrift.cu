#include "GenComputation.cuh"
#include "HelModVariableStructure.cuh"
#include "VariableStructure.cuh"
#include "MagneticDrift.cuh"
#include "SolarWind.cuh"


#include <stdio.h>          // Supplies FILE, stdin, stdout, stderr, and the fprint() family of functions


////////////////////////////////////////////////////////////////
//..... Magnetic Drift Model ..................................
//.... Potgieter Mooral 1985 - See Burger&Hatttingh 1995
////////////////////////////////////////////////////////////////
__device__ float Gamma_Bfield(float r, float th, float Vsw) {
    return (Omega * (r - rhelio) * sinf(th)) / Vsw;
}

__device__ float delta_Bfield(float r, float th) {
    return r / rhelio * delta_m / sinf(th);;
}

__device__ vect3D_t Drift_PM89(unsigned char InitZone, signed char HZone, float r, float th, float phi, float R,
                               struct PartDescription_t pt) {
    /*Authors: 2022 Stefano */
    /* * description: Evalaute drift velocity vector, including Neutral sheetdrift. This drift is based on Potgieter e Mooral Model (1989), this model was modified to include a theta-component in Bfield.
     *  Imporant warning: the model born as 2D model for Pure Parker Field, originally this not include theta-component in Bfield.
     *  The implementation can be not fully rigorous,
        \param HZone   Zone in the Heliosphere
        \param part    particle position and energy
        \param pt      particle properties (Z,A,T0)
        \return drift velocity vector including Neutral sheet drift

        Additionally, global CR drifts are believed to be reduced due to the presence of turbulence (scattering; e.g., Minnie et al. 2007). This is incorporated into the modulation
        model by defining the drift reduction factor.
        See:  Strauss et al 2011, Minnie et al 2007 Burger et al 2000
     */
#define sq(x) ((x)*(x))
//@formatter:off
    vect3D_t v;
    const float IsPolarRegion = fabsf(cosf(th)) > CosPolarZone;
    const float Ka = sign(pt.Z) * GeV * beta_R(R, pt) * R / 3;
    const float Asun = LIM[InitZone + HZone].Asun;
    const float dV_dth = DerivativeOfSolarWindSpeed_dtheta(InitZone, HZone, r, th, phi);
    const float TiltAngle = LIM[InitZone + HZone].TiltAngle;
    // .. Scaling factor of drift in 2D approximation.  to account Neutral sheet
    float fth = 0; /* scaling function of drift vel */
    float Dftheta_dtheta = 0;
    const float TiltPos_r = r;
    const float TiltPos_th = Pi / 2.f - TiltAngle;
    const float TiltPos_phi = phi;
    float Vsw = SolarWindSpeed(InitZone, HZone, TiltPos_r, TiltPos_th, TiltPos_phi);
    const float dthetans = fabsf(GeV / (c * aum) * (2.f * r * R) / (Asun * sqrtf(1 + sq(Gamma_Bfield(r, TiltPos_th, Vsw)) + IsPolarRegion * sq(delta_Bfield(r, TiltPos_th)))));

    if (const float theta_mez = Pi / 2.f - 0.5f * sinf(fminf(TiltAngle + dthetans, Pi / 2.f));
        theta_mez < Pi / .2f) {
        const float a_f = acosf(Pi / (2.f * theta_mez) - 1);
        fth = 1.f / a_f * atanf((1.f - 2.f * th / Pi) * tanf(a_f));
        Dftheta_dtheta = -2.f * tanf(a_f) / (a_f * Pi * (1.f + (1 - 2.f * th / Pi) * (1 - 2.f * th / Pi) * tanf(a_f) * tanf(a_f)));
    } else {
        fth = sign(th - Pi / 2.f);
    }

    Vsw = SolarWindSpeed(InitZone, HZone, r, th, phi);

    const float dm = IsPolarRegion ? delta_m : 0;

    const float E = dm * dm * r * r * Vsw * Vsw + Omega * Omega * rhelio * rhelio * (r - rhelio) * (r - rhelio) * sinf(th) * sinf(th) * sinf(th) * sinf(th) + rhelio * rhelio * Vsw * Vsw * sinf(th) * sinf(th);
    float C = fth * sinf(th) * Ka * r * rhelio / (Asun * E * E);
    C *= R * R / (R * R + LIM[InitZone + HZone].P0d * LIM[InitZone + HZone].P0d);

    v.r = -C * Omega * rhelio * 2 * (r - rhelio) * sinf(th) * ((2 * dm * dm * r * r + rhelio * rhelio * sinf(th) * sinf(th)) * Vsw * Vsw * Vsw * cosf(th) - .5f * (dm * dm * r * r * Vsw * Vsw - Omega * Omega * rhelio * rhelio * (r - rhelio) * (r - rhelio) * sinf(th) * sinf(th) * sinf(th) * sinf(th) + rhelio * rhelio * Vsw * Vsw * sinf(th) * sinf(th)) * sinf(th) * dV_dth);
    v.th = -C * Omega * rhelio * Vsw * sinf(th) * sinf(th) * (2 * r * (r - rhelio) * (dm * dm * r * Vsw * Vsw + Omega * Omega * rhelio * rhelio * (r - rhelio) * sinf(th) * sinf(th) * sinf(th) * sinf(th)) - (4 * r - 3 * rhelio) * E);
    v.phi = 2 * C * Vsw * (-dm * dm * r * r * (dm * r + rhelio * cosf(th)) * Vsw * Vsw * Vsw + 2 * dm * r * E * Vsw - Omega * Omega * rhelio * rhelio * (r - rhelio) * sinf(th) * sinf(th) * sinf(th) * sinf(th) * (dm * r * r * Vsw - rhelio * (r - rhelio) * Vsw * cosf(th) + rhelio * (r - rhelio) * sinf(th) * dV_dth));

    C = Vsw * Dftheta_dtheta * sinf(th) * sinf(th) * Ka * r * rhelio * rhelio / (Asun * E);
    C *= R * R / (R * R + LIM[InitZone + HZone].P0dNS * LIM[InitZone + HZone].P0dNS);

    v.r += -C * Omega * sinf(th) * (r - rhelio);

    v.phi += -C * Vsw;

    const float HighRigiSupp = LIM[InitZone + HZone].plateau + (1.f - LIM[InitZone + HZone].plateau) / (1.f + expf(HighRigiSupp_smoothness * (R - HighRigiSupp_TransPoint)));
    v.r *= HighRigiSupp;
    v.th *= HighRigiSupp;
    v.phi *= HighRigiSupp;
    //@formatter:on
    return v;
#undef sq
}


float EvalP0DriftSuppressionFactor(int WhichDrift, int SolarPhase, float TiltAngleDeg, float ssn) {
    //WhichDrift = 0 - Regular drift
    //WhichDrift = 1 - NS drift

    float InitialVal, FinalVal, CenterOfTransition, smoothness;

    if (WhichDrift == 0) {
        // reg drift
        InitialVal = TDDS_P0d_Ini;
        FinalVal = TDDS_P0d_Fin;
        if (SolarPhase == 0) {
            CenterOfTransition = TDDS_P0d_CoT_asc;
            smoothness = TDDS_P0d_Smt_asc;
        } else {
            CenterOfTransition = TDDS_P0d_CoT_des;
            smoothness = TDDS_P0d_Smt_des;
        }
    } else {
        //NS drift
        InitialVal = TDDS_P0dNS_Ini;
        FinalVal = ssn / SSNScalF;
        if (SolarPhase == 0) {
            CenterOfTransition = TDDS_P0dNS_CoT_asc;
            smoothness = TDDS_P0dNS_Smt_asc;
        } else {
            CenterOfTransition = TDDS_P0dNS_CoT_des;
            smoothness = TDDS_P0dNS_Smt_des;
        }
    }
    ////////////////////////////////////////////////
    // printf("-- SolarPhase_v[izone]: %d \n",SolarPhase);
    // printf("-- TiltAngle_v[izone] : %.0lf \n",TiltAngleDeg);
    // if (WhichDrift==0)
    // {
    //   printf("-- TDDS_P0d_Ini       : %e \n",InitialVal);
    //   printf("-- TDDS_P0d_Fin       : %.e \n",FinalVal);
    //   printf("-- CenterOfTransition : %e \n",CenterOfTransition);
    //   printf("-- smoothness         : %e \n",smoothness);
    //   printf("-- P0d                : %e \n",SmoothTransition(InitialVal,  FinalVal,  CenterOfTransition,  smoothness,  TiltAngleDeg));


    // }
    ////////////////////////////////////////////////
    return SmoothTransition(InitialVal, FinalVal, CenterOfTransition, smoothness, TiltAngleDeg);
}

float EvalHighRigidityDriftSuppression_plateau(int SolarPhase, float TiltAngleDeg) {
    // Plateau time dependence
    float CenterOfTransition, smoothness;
    if (SolarPhase == 0) {
        CenterOfTransition = HRS_TransPoint_asc;
        smoothness = HRS_smoothness_asc;
    } else {
        CenterOfTransition = HRS_TransPoint_des;
        smoothness = HRS_smoothness_des;
    }
    return 1.f - SmoothTransition(1.f, 0.f, CenterOfTransition, smoothness, TiltAngleDeg);
}
