file(REMOVE_RECURSE
  "CMakeFiles/IgnoreThisTarget.dir/kernel_test.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/kernel_test.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/DiffusionModel.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/DiffusionModel.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/GPUManage.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/GPUManage.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/GenComputation.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/GenComputation.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HelModLoadConfiguration.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HelModLoadConfiguration.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphereModel.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphereModel.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphericPropagation.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphericPropagation.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HistoComputation.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/HistoComputation.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/Histogram.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/Histogram.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/LoadConfiguration.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/LoadConfiguration.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/MagneticDrift.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/MagneticDrift.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/SDECoeffs.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/SDECoeffs.cu.o.d"
  "CMakeFiles/IgnoreThisTarget.dir/sources/SolarWind.cu.o"
  "CMakeFiles/IgnoreThisTarget.dir/sources/SolarWind.cu.o.d"
  "IgnoreThisTarget"
  "IgnoreThisTarget.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CUDA)
  include(CMakeFiles/IgnoreThisTarget.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
