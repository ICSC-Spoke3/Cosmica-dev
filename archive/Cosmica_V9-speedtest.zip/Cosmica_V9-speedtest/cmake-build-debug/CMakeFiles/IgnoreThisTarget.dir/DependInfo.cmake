
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/kernel_test.cu" "CMakeFiles/IgnoreThisTarget.dir/kernel_test.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/kernel_test.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/DiffusionModel.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/DiffusionModel.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/DiffusionModel.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/GPUManage.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/GPUManage.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/GPUManage.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/GenComputation.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/GenComputation.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/GenComputation.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/HelModLoadConfiguration.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/HelModLoadConfiguration.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/HelModLoadConfiguration.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/HeliosphereModel.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphereModel.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphereModel.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/HeliosphericPropagation.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphericPropagation.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/HeliosphericPropagation.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/HistoComputation.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/HistoComputation.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/HistoComputation.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/Histogram.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/Histogram.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/Histogram.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/LoadConfiguration.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/LoadConfiguration.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/LoadConfiguration.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/MagneticDrift.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/MagneticDrift.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/MagneticDrift.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/SDECoeffs.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/SDECoeffs.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/SDECoeffs.cu.o.d"
  "/home/leone.bacciu/Cosmica-dev/Cosmica_V9-speedtest/sources/SolarWind.cu" "CMakeFiles/IgnoreThisTarget.dir/sources/SolarWind.cu.o" "gcc" "CMakeFiles/IgnoreThisTarget.dir/sources/SolarWind.cu.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
