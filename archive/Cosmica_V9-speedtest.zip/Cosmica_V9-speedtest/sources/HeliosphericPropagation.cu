#include <stdio.h>
#include <math.h>
#include <curand.h>         // CUDA random number host library
#include <curand_kernel.h>  // CUDA random number device library
#include <cuda_runtime.h>
#include "HeliosphericPropagation.cuh"
#include "VariableStructure.cuh"
#include "HelModVariableStructure.cuh"
#include "HeliosphereLocation.cuh"
#include "HeliosphereModel.cuh"
#include "SDECoeffs.cuh"
#include "GenComputation.cuh"
#include "Histogram.cuh"

// use template for the needs of unrolled max search in BlockMax
__global__ void HeliosphericProp(int Npart_PerKernel, float Min_dt, float Max_dt, float TimeOut,
                                 struct QuasiParticle_t QuasiParts_out, int *PeriodIndexes, struct PartDescription_t pt,
                                 curandStatePhilox4_32_10_t *CudaState, float *RMaxs) {
    int id = threadIdx.x + blockIdx.x * blockDim.x;
    if (id >= Npart_PerKernel) return;

    // Deine the external unique share memory array
    extern __shared__ float smem[];

    // __shared__ int Npart;
    // __shared__ float dt;
    // __shared__ float sqrtf(dt) = 0;
    // float MinValueTimeStep = Min_dt;
    // float MaxValueTimeStep = Max_dt;
    // int Npart = Npart_PerKernel;
    // struct PartDescription_t p_descr = pt;

    //__shared__ curandStatePhilox4_32_10_t LocalState[Npart_PerKernel];

    //__shared__ int ZoneNum[Npart_PerKernel];

    // subdivide the shared memory in the various variable arrays
    // CHECK TO NOT DOUBLE USE POINTERS WITH NOT NEEDED REGISTERS
    /* float* r      = &r;
    float* th        = &th;
    float* phi       = &smem[threadIdx.x + 2*blockDim.x];
    float* R         = &smem[threadIdx.x + 3*blockDim.x];
    float* t_fly     = &smem[threadIdx.x + 4*blockDim.x];
    float* alphapath = &smem[threadIdx.x + 5*blockDim.x] ;
    float* zone      = &smem[threadIdx.x + 5*blockDim.x]; */

    // Execute only the thread filled with quasi-particle to propagate
    curandStatePhilox4_32_10_t randState = CudaState[id];
    // Copy the particle variables to shared memory for less latency
    float r = QuasiParts_out.r[id];
    float th = QuasiParts_out.th[id];
    float phi = QuasiParts_out.phi[id];
    float &R = smem[threadIdx.x + 3 * blockDim.x] = QuasiParts_out.R[id];
    float t_fly = QuasiParts_out.t_fly[id];
    // smem[threadIdx.x + 5*blockDim.x] =  QuasiParts_out.alphapath[id];

    // Initialize the quasi particle position
#if TRIVIAL
      smem[threadIdx.x + 5*blockDim.x] = Zone(r, th, smem[threadIdx.x + 2*blockDim.x]);
#else
    int rad_zone = RadialZone(PeriodIndexes[id], r, th, phi);
#endif

    // Initialize the random state seed per thread
    //LocalState[id] = CudaState[id];

    // Stocasti propagation cycle until quasi-particle exit heliosphere or it reaches the fly timeout
    while (rad_zone >= 0 && t_fly <= TimeOut) {
        float4 RandNum = curand_normal4(&randState); // x,y,z used for SDE, w used for K0 random oscillation

        // Initialization of the propagation terms
        struct DiffusionTensor_t KSym;
        struct Tensor3D_t Ddif;
        struct vect3D_t AdvTerm;
        float en_loss;
        // float loss_term;
        float dt = Max_dt;

#if TRIVIAL
        // Evaluate the convective-diffusive tensor and its decomposition
        KSym = trivial_DiffusionTensor_symmetric(smem[threadIdx.x + 5*blockDim.x]); // Needed only to compute the two following terms
        Ddif = trivial_SquareRoot_DiffusionTensor(KSym);

        // Evaluate advective-drift vector
        AdvTerm = trivial_AdvectiveTerm(KSym);

        // Evaluate the energy loss term
        en_loss = fabsf(RandNum.x)*trivial_EnergyLoss();

        // Evaluate the loss term (Montecarlo statistical weight)
        // loss_term = 0;

        // Evaluate the time step of the SDE (dynamic or static time step? if it's dynamic would be also be individual for each thread?)
        dt = Max_dt/100;

#else
        // Evaluate the convective-diffusive tensor and its decomposition
        KSym = DiffusionTensor_symmetric(PeriodIndexes[id], rad_zone, r, th, phi, R, pt, RandNum.w);

        int res = 0;
        Ddif = SquareRoot_DiffusionTerm(rad_zone, KSym, r, th, &res);

        if (res > 0) {
            // SDE diffusion matrix is not positive definite; in this case propagation should be stopped and a new event generated
            // placing the energy below zero ensure that this event is ignored in the after-part of the analysis
            R = -1;
            break; //exit the while cycle
        }


        // Evaluate advective-drift vector
        AdvTerm = AdvectiveTerm(PeriodIndexes[id], rad_zone, KSym, r, th, phi, R, pt);

        // Evaluate the energy loss term
        en_loss = EnergyLoss(PeriodIndexes[id], rad_zone, r, th, phi, R);

        // Evaluate the loss term (Montecarlo statistical weight)
        // loss_term = LossTerm(PeriodIndexes[id], smem[threadIdx.x + 5*blockDim.x], r, th, smem[threadIdx.x + 2*blockDim.x], smem[threadIdx.x + 3*blockDim.x], pt.T0);

        // evaluate time step
        dt = Max_dt;
        // time step is modified to ensure the diffusion approximation (i.e. diffusion step>>advective step)
        if (dt > Min_dt * (Ddif.rr * Ddif.rr) / (AdvTerm.r * AdvTerm.r))
            dt = max(Min_dt, Min_dt * (Ddif.rr * Ddif.rr) / (AdvTerm.r * AdvTerm.r));
        if (dt > Min_dt * (Ddif.tr + Ddif.tt) * (Ddif.tr + Ddif.tt) / (AdvTerm.th * AdvTerm.th))
            dt = max(Min_dt, Min_dt * (Ddif.tr + Ddif.tt) * (Ddif.tr + Ddif.tt) / (AdvTerm.th * AdvTerm.th));
#endif

        float prev_r = r;

        // Stochastic integration using the coefficients computed above and energy loss term
        r += AdvTerm.r * dt + RandNum.x * Ddif.rr * sqrtf(dt);

        // Reflect out the particle (use previous propagation step) if is closer to the sun than 0.3f AU
        if (r < Heliosphere.Rmirror) {
            r = prev_r;
        } else {
            th += AdvTerm.th * dt + (RandNum.x * Ddif.tr + RandNum.y * Ddif.tt) *
                    sqrtf(dt);
            phi += AdvTerm.phi * dt + (
                RandNum.x * Ddif.pr + RandNum.y * Ddif.pt + RandNum.z * Ddif.pp) * sqrtf(dt);
            R += en_loss * dt;
            t_fly += dt;
            // smem[threadIdx.x + 5*blockDim.x] += loss_term*dt;
        }

        // Remap the polar coordinates inside their range (th in [0, Pi] & phi in [0, 2*Pi])
        th = fabsf(th);
        th = fabsf(
            fmodf(2 * Pi + sign(Pi - th) * th, Pi));
        // --- reflecting latitudinal bounduary
        if (th > thetaSouthlimit) {
            th = 2 * thetaSouthlimit - th;
        } else if (th < (thetaNorthlimit)) {
            th = 2 * thetaNorthlimit - th;
        }

        phi = fmodf(phi, 2 * Pi);
        phi = fmodf(2 * Pi + phi, 2 * Pi);

        // Check of the zone of heliosphere, heliosheat or interstellar medium where the quasi-particle is after a step
#if TRIVIAL
        smem[threadIdx.x + 5*blockDim.x] = Zone(r, th, smem[threadIdx.x + 2*blockDim.x]);
#else
        rad_zone = RadialZone(PeriodIndexes[id], r, th, phi);
#endif
    }

    // Save peopagation exit values
    QuasiParts_out.r[id] = r;
    QuasiParts_out.th[id] = th;
    QuasiParts_out.phi[id] = phi;
    QuasiParts_out.R[id] = R;
    QuasiParts_out.t_fly[id] = t_fly;
    // QuasiParts_out.alphapath[id] = smem[threadIdx.x + 5*blockDim.x];

    // Find the maximum rigidity inside the block
    BlockMax(smem, RMaxs);
}
