from glob import glob
from os.path import join as pjoin, dirname
import numpy as np
from matplotlib import pyplot as plt
from matplotlib import colors as mcolors

from lib.files_utils import load_simulation_outputs_yaml, load_simulation_output, load_simulation_outputs, \
    load_simulation_list, load_lis
from lib.physics_utils import evaluate_modulation
from lib.files_utils import load_experimental_data

# Setting rc params for all plots

plt.rcdefaults()

rc_params = {
    'axes.titlesize': 20,
    'axes.labelsize': 15,
    'xtick.labelsize': 8,
    'ytick.labelsize': 8,
    'lines.linewidth': 1,
    'axes.grid': True,
    'figure.titlesize': 30,
    'axes.prop_cycle': plt.cycler(color=plt.cm.Dark2.colors),
}

plt.rcParams.update(rc_params)

colors = ['silver', 'skyblue', 'royalblue', 'blue', 'navy']
color_positions = [0.0, 0.25, 0.5, 0.75, 1]  # range of each color
cmap = mcolors.LinearSegmentedColormap.from_list('custom_colormap', list(zip(color_positions, colors)), N=1000)


# cmap = 'inferno'


def evaluate_output(outputs, experimental_data, lis, plot_path=None):
    """
    Evaluate the output of a simulation and compare it with experimental data.
    :param output_path: path to the output file
    :param experimental_data: experimental data
    :param lis: LIS data
    :param rig_in: if the output is in energy
    :param plot_path: path to save the plot, if None the plot is not saved
    :return: RMSE between the simulation and the experimental data
    """

    outputs = load_simulation_outputs(outputs)

    sim_en_rig, sim_j_mod, j_lis = evaluate_modulation(outputs, lis)
    exp_en_rig, exp_j_mod = experimental_data.T[:2]

    assert np.allclose(sim_en_rig, exp_en_rig, rtol=0.02 * sim_en_rig)

    print(np.subtract(sim_j_mod, exp_j_mod))
    rmse = np.sqrt(np.square(np.subtract(sim_j_mod, exp_j_mod)).mean())

    if plot_path is not None:
        fig, ax = plt.subplots(figsize=(12, 8))

        # Plot simulation and LIS
        ax.plot(sim_en_rig, sim_j_mod, label=r'$\text{Simulated: Cosmica}$', color='royalblue', linewidth=2)
        ax.plot(sim_en_rig, j_lis, label=r'$\text{Local Interstellar Spectrum (LIS)}$',
                color='navy', linestyle='--', linewidth=1.5)

        # Plot experimental data with error bars
        # ax.errorbar(exp_en_rig, exp_j_mod, yerr=[exp_inf, exp_sup], fmt='o',
        #             label=r'$\text{Experimental Data}$', color='crimson', markersize=5, capsize=4, elinewidth=1)
        ax.scatter(exp_en_rig, exp_j_mod, marker='o',
                    label=r'$\text{Experimental Data}$', color='crimson', s=5)

        ax.set_xscale('log')
        ax.set_yscale('log')
        ax.set_xlabel(r'$\text{Energy Rigidity (GV)}$', fontsize=16)
        ax.set_ylabel(
            r'$\text{Flux } \left(\frac{1}{\mathrm{GeV}/n \, \mathrm{m}^2 \, \mathrm{sr} \, \mathrm{s}}\right)$',
            fontsize=16)
        ax.set_title(rf'$\text{{Comparison of }} {list(outputs.keys())} \text{{ Simulation with Experimental Data}}$',
                     fontsize=20,
                     pad=20)

        ax.tick_params(axis='both', which='major', labelsize=12)
        ax.tick_params(axis='both', which='minor', labelsize=10)

        ax.grid(visible=True, which='major', linestyle='-', linewidth=0.75, alpha=0.8)  # Prominent major grid
        ax.grid(visible=True, which='minor', linestyle=':', linewidth=0.5, alpha=0.5)  # Subtle minor grid

        ax.legend(loc='upper right', fontsize=12, frameon=True)
        plt.subplots_adjust(right=0.8)

        plt.tight_layout()
        plt.savefig(plot_path, dpi=300)
        plt.close()

    return rmse


if __name__ == "__main__":
    ROOTDIR = pjoin(dirname(__file__), 'data')
    plis = pjoin(ROOTDIR, 'GALPROP_LIS_Esempio')
    pcosmica = pjoin(dirname(dirname(__file__)), 'Cosmica_V6-speedtest', 'exefiles', 'Cosmica')
    pinputs = pjoin(ROOTDIR, 'inputs')
    poutputs = pjoin(ROOTDIR, 'outputs')
    pexp = pjoin(ROOTDIR, 'raw')
    psims = pjoin(ROOTDIR, f'Simulations.list')
    pplots = pjoin(dirname(__file__), 'plots')

    sim_list = load_simulation_list(psims)
    lis = load_lis(plis)

    outputs = glob(pjoin(poutputs, '*.dat'))
    print(outputs)

    for sim_name, ions, file_name, init_date, end_date, rad, lat, lon in sim_list:
        print(sim_name, init_date)
        proton_res = next(filter(lambda f: init_date in f and 'Proton' in f, outputs), None)
        deuteron_res = next(filter(lambda f: init_date in f and 'Deuteron' in f, outputs), None)
        exp_data = load_experimental_data(pexp, file_name, (0, 100), ncols=2)
        if all([proton_res, deuteron_res]):
            print(evaluate_output([proton_res, deuteron_res], exp_data, lis, pjoin(pplots, f'{sim_name}.png')))
        else:
            print(proton_res, deuteron_res)
        print()

