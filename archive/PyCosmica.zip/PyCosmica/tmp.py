import re

def extract_function_names(file_path):
    """
    Extracts function names from a given Python file.

    Args:
        file_path (str): Path to the Python file to parse.

    Returns:
        list: A list of extracted function names.
    """
    try:
        with open(file_path, 'r') as file:
            content = file.read()
            print(content)
            # Regular expression pattern to match function definitions
            pattern = r'\ndef\s+(\w+)\s*\('
            matches = re.findall(pattern, content)
            return matches
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return []

def main():
    file_path = "/home/matteo.grazioso/Cosmica-dev/PyCosmica/utils/sde_func.py"
    function_names = extract_function_names(file_path)
    print("Extracted Function Names:")
    print(', '.join(function_names))

if __name__ == "__main__":
    main()